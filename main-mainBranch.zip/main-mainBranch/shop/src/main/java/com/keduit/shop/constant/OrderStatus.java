package com.keduit.shop.constant;

public enum OrderStatus {
    ORDER, CANCEL, RETURN_REQUEST, RETURN_COMPLETED, DELIVERING, DELIVERED
}
