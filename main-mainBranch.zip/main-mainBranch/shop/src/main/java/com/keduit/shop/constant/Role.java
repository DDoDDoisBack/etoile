package com.keduit.shop.constant;

public enum Role {
    USER, ADMIN
}
