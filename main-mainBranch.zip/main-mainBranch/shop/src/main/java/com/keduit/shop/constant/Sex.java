package com.keduit.shop.constant;

public enum Sex {
    FEMALE, MALE
}
