package com.keduit.shop.constant;

public enum ItemSellStatus {
    SELL, SOLD_OUT,STOP_SALE
}
